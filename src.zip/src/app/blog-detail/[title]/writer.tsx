"use client";
import { useAccountStore } from "@/lib/store/accountStore";


function BlogDetailWriter(){

    const signInHistory = useAccountStore((state) => state.signInHistory);
    return(
        <h5 className="text-neutral-500">
              {signInHistory.map((username, idx) => (
                <div key={idx}>{`Written by: ${username}`}</div>
              ))}
            </h5>
    )
}

export default BlogDetailWriter