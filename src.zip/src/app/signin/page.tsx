"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import axios from "axios";
import { useRouter } from "next/navigation";
import { useAccountStore } from "@/lib/store/accountStore";
import { Formik, Form, FormikProps, FormikValues } from "formik";
import { ISignInValue, SignInSchema } from "./SigninSchema";
import { Input } from "@/components/ui/input";
import { Eye, EyeOff } from "lucide-react";

const SignIn = () => {
  const router = useRouter();

  // use global state from zustand untuk save data account that signed in
  const addSignInHistory = useAccountStore((state) => state.addSignInHistory);
  const signInHistory = useAccountStore((state) => state.signInHistory);
  const setAccount = useAccountStore((state) => state.setAccount);

  const [showPassword, setShowPassword] = useState(false);

  // untuk mencari data user di database
  const onSignin = async (values: ISignInValue) => {
    try {
      const result = await axios.get(
        "https://upwardskin-us.backendless.app/api/data/accounts",
        {
          params: {
            where: `email='${values.email}' AND password='${values.password}'`,
          },
        }
      );
      console.log(result.data); //checking error

      if (result.data && result.data[0]) {
        addSignInHistory(result.data[0].username); //save sign in history, untuk ditampilkan nama username pada app
        setAccount(result.data[0].objectId);
        alert(`selamat datang ${result.data[0].username}`);
      }
    } catch (error) {
      console.log("form error", error);
    }
  };

  if (signInHistory[0]) {
    router.replace("/"); //pindah ke home page, untuk protect sign in page
  }

  return (
    <div className="flex flex-col h-screen">
      <main className="flex-1 flex items-center justify-center">
        <div className="flex flex-col gap-4 w-full max-w-md px-4">
          <h1 className="text-2xl font-bold text-center">Welcome back!</h1>
          <p className="text-center text-gray-600 dark:text-gray-400">
            Sign in to your account to continue writing
          </p>

          <Formik
            initialValues={{ email: "", password: "" }}
            validationSchema={SignInSchema}
            onSubmit={onSignin}
          >
            {(props: FormikProps<ISignInValue>) => {
              const { errors, values, handleChange } = props;
              console.log(errors);
              return (
                <Form>
                  <div>
                    <Card className="p-6 bg-white dark:bg-gray-800 shadow-md">
                      <div className="flex flex-col gap-4">
                        <div className="flex flex-col gap-3">
                          <div className="flex flex-col gap-0">
                            <label>Your email</label>
                            <span className="text-red-400 italic text-sm">
                              {errors.email}
                            </span>
                          </div>
                          <Input
                            name="email" //name untuk acuan formik mengambil value; name harus sesuai dengan yang ada di schema
                            type="email"
                            placeholder="your@email.com"
                            onChange={handleChange}
                            className="p-2 border border-gray-300 rounded dark:bg-gray-700 dark:border-gray-600"
                          />
                        </div>

                        <div className="flex flex-col gap-3">
                          <div className="flex flex-col gap-0">
                            <label>Your password</label>
                            <span className="text-red-400 italic text-sm">
                              {errors.password}
                            </span>
                          </div>

                          <div className="relative w-full">
                            <Input
                              name="password"
                              type={showPassword ? "text" : "password"}
                              placeholder="Enter your password"
                              className="p-2 border border-gray-300 rounded dark:bg-gray-700 dark:border-gray-600"
                              onChange={handleChange}
                            />

                            <Button
                              type="button"
                              onClick={() => setShowPassword((prev) => !prev)}
                              className="absolute right-2 top-2 text-gray-500 hover:text-black w-1 h-1"
                              variant={"ghost"}
                            >
                              {showPassword ? (
                                <Eye size={20} />
                              ) : (
                                <EyeOff size={20} />
                              )}
                            </Button>
                          </div>
                        </div>

                        <Button
                          variant={"outline"}
                          type="submit"
                          className="text-white p-2 rounded  hover:bg-neutral-800 hover:text-white transition-colors border-gray-300 mt-[20px] bg-black"
                        >
                          Sign In
                        </Button>
                      </div>
                    </Card>
                  </div>
                </Form>
              );
            }}
          </Formik>
          <div className="flex justify-center">
            <p className="text-gray-600 flex flex-col justify-center">
              Don't have an account?
            </p>
            <a href="/signup">
              <Button
                type="button"
                variant={"link"}
                className="text-gray-600 hover:text-grey-400 p-0 pl-1.5"
              >
                Sign Up
              </Button>
            </a>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SignIn;
